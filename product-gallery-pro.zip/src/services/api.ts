/**
 * API Service for Google Apps Script Web App
 */

// THAY THẾ URL NÀY BẰNG WEB APP URL CỦA BẠN SAU KHI DEPLOY GAS
const GAS_WEB_APP_URL = "https://script.google.com/macros/s/AKfycbxd9X7csGC9wGXYqjrgBO4vtgd38DEaA_1UZceCV9daTFLl5vpFYaFm82dcysB-qKLk/exec";

export const api = {
  async getProducts() {
    try {
      const proxyUrl = `/api/proxy-gas?url=${encodeURIComponent(GAS_WEB_APP_URL)}`;
      const response = await fetch(proxyUrl);
      if (!response.ok) throw new Error("Network response was not ok");
      return await response.json();
    } catch (error) {
      console.error("Fetch error:", error);
      throw error;
    }
  },

  async addProduct(payload: any) {
    try {
      const proxyUrl = `/api/proxy-gas?url=${encodeURIComponent(GAS_WEB_APP_URL)}`;
      const response = await fetch(proxyUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });
      if (!response.ok) throw new Error("Failed to add product via proxy");
      return await response.json();
    } catch (error) {
      console.error("Post error:", error);
      throw error;
    }
  }
};
