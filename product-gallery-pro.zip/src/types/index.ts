export interface Product {
  ID: string;
  Name: string;
  Brand: string;
  Tags: string[];
  ImageLinks: string[];
  CreatedAt: string;
}

export interface ImageItem {
  id: string;
  url: string;
  productName: string;
  brand: string;
  tags: string[];
}

export interface ProductPayload {
  name: string;
  brand: string;
  tags: string[];
  imageLinks: string[];
}
