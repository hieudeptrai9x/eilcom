import { useState, useEffect } from 'react';
import { Product, ProductPayload } from '../types';
import { api } from '../services/api';

export function useProducts() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const data = await api.getProducts();
      setProducts(data);
      setError(null);
    } catch (err) {
      setError("Không thể tải dữ liệu từ Google Sheets. Hãy kiểm tra URL Web App.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const addProduct = async (payload: ProductPayload) => {
    try {
      await api.addProduct(payload);
      // Refresh list after adding
      setTimeout(fetchProducts, 1500); // Wait a bit for GAS to process
      return true;
    } catch (err) {
      console.error(err);
      return false;
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  return { products, loading, error, fetchProducts, addProduct };
}
