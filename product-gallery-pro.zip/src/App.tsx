/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo } from 'react';
import { useProducts } from './hooks/useProducts';
import ProductForm from './components/ProductForm';
import ProductGrid from './components/ProductGrid';
import SearchBar from './components/SearchBar';
import ImagePreviewModal from './components/ImagePreviewModal';
import { LayoutGrid, Sparkles, Github, Search, PlusCircle, Image as ImageIcon, Grid3X3, ArrowLeft, ChevronRight, Package, Download, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ImageItem, Product } from './types';

type TabType = 'search' | 'all' | 'import';

export default function App() {
  const { products, loading, addProduct } = useProducts();
  const [activeTab, setActiveTab] = useState<TabType>('search');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [displayLimit, setDisplayLimit] = useState(40);
  const [previewContext, setPreviewContext] = useState<{ items: ImageItem[], index: number } | null>(null);
  const [isDownloadingAll, setIsDownloadingAll] = useState(false);
  const [showDownloadConfirm, setShowDownloadConfirm] = useState(false);

  // Filter products for search tab
  const filteredProducts = useMemo(() => {
    if (!searchQuery) return [];
    const query = searchQuery.toLowerCase();
    return products.filter(p => 
      p.Name.toLowerCase().includes(query) ||
      p.Brand.toLowerCase().includes(query) ||
      (p.Tags && p.Tags.some(tag => tag.toLowerCase().includes(query)))
    );
  }, [products, searchQuery]);

  // Flatten images for "All Images" tab with limit
  const allImageItems = useMemo(() => {
    const items: ImageItem[] = [];
    products.forEach(product => {
      product.ImageLinks.forEach((link) => {
        items.push({
          id: product.ID,
          url: link,
          productName: product.Name,
          brand: product.Brand,
          tags: product.Tags || []
        });
      });
    });
    return items;
  }, [products]);

  const imagesToShow = useMemo(() => {
    return allImageItems.slice(0, displayLimit);
  }, [allImageItems, displayLimit]);

  // Images for the selected product in search tab
  const selectedProductImages = useMemo(() => {
    if (!selectedProduct) return [];
    return selectedProduct.ImageLinks.map(link => ({
      id: selectedProduct.ID,
      url: link,
      productName: selectedProduct.Name,
      brand: selectedProduct.Brand,
      tags: selectedProduct.Tags || []
    }));
  }, [selectedProduct]);

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
  };

  const handleBackToSearch = () => {
    setSelectedProduct(null);
  };

  const handleDownloadAll = async (items: ImageItem[]) => {
    if (isDownloadingAll || items.length === 0) return;
    
    setIsDownloadingAll(true);
    setShowDownloadConfirm(false);
    
    try {
      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        const proxyUrl = `/api/proxy-image?url=${encodeURIComponent(item.url)}`;
        const response = await fetch(proxyUrl);
        const contentType = response.headers.get('content-type');
        const extension = contentType?.split('/')[1] || 'jpg';
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${item.productName.replace(/\s+/g, '-').toLowerCase()}-${i}.${extension}`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        
        // Small delay to prevent browser from blocking multiple downloads
        await new Promise(resolve => setTimeout(resolve, 300));
      }
    } catch (err) {
      console.error('Download all error:', err);
    } finally {
      setIsDownloadingAll(false);
    }
  };

  return (
    <div className="min-h-screen pb-24 bg-[#F8F9FA]">
      {/* Header Section */}
      <header className="pt-12 pb-8 px-6">
        <div className="max-w-7xl mx-auto flex flex-col items-center text-center">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-black text-white text-xs font-bold tracking-widest uppercase mb-6"
          >
            <Sparkles size={14} /> Product Gallery Pro
          </motion.div>
          
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-8 bg-gradient-to-b from-gray-900 to-gray-500 bg-clip-text text-transparent">
            Thư viện Ảnh Thông minh.
          </h1>

          {/* Tab Switcher */}
          <div className="flex p-1 bg-gray-200/50 backdrop-blur-md rounded-2xl w-full max-w-xl mx-auto mb-8">
            <button
              onClick={() => { setActiveTab('search'); setSelectedProduct(null); }}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold transition-all ${
                activeTab === 'search' ? 'bg-white text-black shadow-sm' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <Search size={18} /> Tìm kiếm
            </button>
            <button
              onClick={() => setActiveTab('all')}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold transition-all ${
                activeTab === 'all' ? 'bg-white text-black shadow-sm' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <Grid3X3 size={18} /> Toàn bộ ảnh
            </button>
            <button
              onClick={() => setActiveTab('import')}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold transition-all ${
                activeTab === 'import' ? 'bg-white text-black shadow-sm' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <PlusCircle size={18} /> Nhập ảnh
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6">
        <AnimatePresence mode="wait">
          {activeTab === 'search' && (
            <motion.div
              key="search-tab"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              {!selectedProduct ? (
                <>
                  <SearchBar value={searchQuery} onChange={setSearchQuery} />
                  
                  <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center gap-2">
                      <div className="p-2 bg-black text-white rounded-lg">
                        <Package size={18} />
                      </div>
                      <h3 className="text-2xl font-bold tracking-tight">Sản phẩm tìm thấy</h3>
                    </div>
                    <div className="text-sm font-medium text-gray-400 bg-white px-4 py-2 rounded-full shadow-sm">
                      Kết quả: <span className="text-black font-bold">{filteredProducts.length}</span> sản phẩm
                    </div>
                  </div>

                  {/* Product List View (Optimized for performance) */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {filteredProducts.map((product) => (
                      <motion.div
                        key={product.ID}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => handleProductClick(product)}
                        className="glass-card p-5 rounded-3xl cursor-pointer flex items-center justify-between group hover:bg-black hover:text-white transition-all duration-300"
                      >
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-2xl bg-gray-100 flex items-center justify-center group-hover:bg-white/10 overflow-hidden">
                            {product.ImageLinks.length > 0 ? (
                              <img 
                                src={product.ImageLinks[0]} 
                                alt={product.Name}
                                className="w-full h-full object-cover"
                                referrerPolicy="no-referrer"
                                onError={(e) => {
                                  (e.target as HTMLImageElement).src = 'https://picsum.photos/seed/placeholder/100/100';
                                }}
                              />
                            ) : (
                              <ImageIcon size={20} className="text-gray-400 group-hover:text-white" />
                            )}
                          </div>
                          <div>
                            <p className="text-[10px] uppercase tracking-widest font-bold opacity-50">{product.Brand}</p>
                            <h4 className="font-bold truncate max-w-[180px]">{product.Name}</h4>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-xs font-bold px-3 py-1 bg-gray-100 rounded-full group-hover:bg-white/10">
                            {product.ImageLinks.length} ảnh
                          </span>
                          <ChevronRight size={18} className="text-gray-300 group-hover:text-white" />
                        </div>
                      </motion.div>
                    ))}
                    {searchQuery && filteredProducts.length === 0 && (
                      <div className="col-span-full py-20 text-center text-gray-400">
                        Không tìm thấy sản phẩm nào khớp với từ khóa.
                      </div>
                    )}
                    {!searchQuery && (
                      <div className="col-span-full py-20 text-center text-gray-400">
                        Nhập tên sản phẩm hoặc thương hiệu để bắt đầu tìm kiếm.
                      </div>
                    )}
                  </div>
                </>
              ) : (
                <div className="space-y-8">
                  <button 
                    onClick={handleBackToSearch}
                    className="flex items-center gap-2 text-sm font-bold hover:text-gray-600 transition-colors"
                  >
                    <ArrowLeft size={18} /> Quay lại tìm kiếm
                  </button>
                  
                  <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
                    <div>
                      <p className="text-xs uppercase tracking-[0.3em] font-bold text-gray-400 mb-1">{selectedProduct.Brand}</p>
                      <h2 className="text-4xl font-bold tracking-tight">{selectedProduct.Name}</h2>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <button 
                          onClick={() => setShowDownloadConfirm(!showDownloadConfirm)}
                          disabled={isDownloadingAll || selectedProductImages.length === 0}
                          className="flex items-center gap-2 px-4 py-2 bg-black text-white rounded-xl text-sm font-bold hover:bg-gray-800 transition-all disabled:opacity-50"
                        >
                          {isDownloadingAll ? <Loader2 className="animate-spin" size={16} /> : <Download size={16} />}
                          Tải toàn bộ {selectedProduct.ImageLinks.length} ảnh
                        </button>

                        <AnimatePresence>
                          {showDownloadConfirm && (
                            <motion.div
                              initial={{ opacity: 0, y: 10, scale: 0.95 }}
                              animate={{ opacity: 1, y: 0, scale: 1 }}
                              exit={{ opacity: 0, y: 10, scale: 0.95 }}
                              className="absolute bottom-full mb-3 right-0 w-64 bg-white rounded-2xl shadow-2xl border border-gray-100 p-4 z-30"
                            >
                              <p className="text-xs font-medium text-gray-600 mb-3">
                                Bạn muốn tải xuống toàn bộ {selectedProductImages.length} ảnh? Trình duyệt có thể yêu cầu quyền tải nhiều file.
                              </p>
                              <div className="flex gap-2">
                                <button 
                                  onClick={() => handleDownloadAll(selectedProductImages)}
                                  className="flex-1 py-2 bg-black text-white text-[10px] font-bold rounded-lg hover:bg-gray-800"
                                >
                                  Xác nhận tải
                                </button>
                                <button 
                                  onClick={() => setShowDownloadConfirm(false)}
                                  className="flex-1 py-2 bg-gray-100 text-gray-600 text-[10px] font-bold rounded-lg hover:bg-gray-200"
                                >
                                  Hủy
                                </button>
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                      <div className="px-6 py-3 bg-white rounded-2xl shadow-sm border border-gray-100">
                        <span className="text-sm font-bold">Tổng cộng {selectedProduct.ImageLinks.length} ảnh</span>
                      </div>
                    </div>
                  </div>

                  <ProductGrid 
                    items={selectedProductImages} 
                    loading={false} 
                    onPreview={(item) => setPreviewContext({ items: selectedProductImages, index: selectedProductImages.indexOf(item) })} 
                  />
                </div>
              )}
            </motion.div>
          )}

          {activeTab === 'all' && (
            <motion.div
              key="all-tab"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-black text-white rounded-lg">
                    <Grid3X3 size={18} />
                  </div>
                  <h3 className="text-2xl font-bold tracking-tight">Tất cả ảnh trong kho</h3>
                </div>
                <div className="text-sm font-medium text-gray-400 bg-white px-4 py-2 rounded-full shadow-sm">
                  Đang hiển thị <span className="text-black font-bold">{imagesToShow.length}</span> / {allImageItems.length} ảnh
                </div>
              </div>

              <ProductGrid 
                items={imagesToShow} 
                loading={loading} 
                onPreview={(item) => setPreviewContext({ items: imagesToShow, index: imagesToShow.indexOf(item) })} 
              />
              
              {allImageItems.length > displayLimit && (
                <div className="mt-12 flex justify-center">
                  <button 
                    onClick={() => setDisplayLimit(prev => prev + 40)}
                    className="px-12 py-4 bg-white border border-gray-200 rounded-2xl font-bold hover:bg-gray-50 transition-all shadow-sm"
                  >
                    Xem thêm ảnh
                  </button>
                </div>
              )}
            </motion.div>
          )}

          {activeTab === 'import' && (
            <motion.div
              key="import-tab"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className="max-w-3xl mx-auto"
            >
              <ProductForm onAdd={addProduct} />
              
              <div className="glass-card p-8 rounded-[3rem] bg-black text-white mt-8">
                <h4 className="text-xl font-bold mb-6 flex items-center gap-3">
                  <LayoutGrid size={24} className="text-emerald-400" /> Mẹo nhập liệu hiệu quả
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-2">
                    <p className="text-emerald-400 font-bold text-sm uppercase tracking-wider">Định dạng Link</p>
                    <p className="text-sm text-white/60 leading-relaxed">
                      Sử dụng link ảnh trực tiếp (kết thúc bằng .jpg, .png, .webp). Mỗi link nằm trên một dòng riêng biệt.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-emerald-400 font-bold text-sm uppercase tracking-wider">Tự động đồng bộ</p>
                    <p className="text-sm text-white/60 leading-relaxed">
                      Sau khi lưu, hệ thống sẽ mất khoảng 1-2 giây để đồng bộ với Google Sheets trước khi hiển thị ở tab Tìm ảnh.
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Image Preview Modal */}
      {previewContext && (
        <ImagePreviewModal 
          items={previewContext.items} 
          initialIndex={previewContext.index}
          onClose={() => setPreviewContext(null)} 
        />
      )}

      {/* Footer */}
      <footer className="mt-24 pt-12 border-t border-gray-100 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2 font-bold text-xl">
            <div className="w-8 h-8 bg-black rounded-lg" /> ProductGallery
          </div>
          <p className="text-gray-400 text-sm">© 2026 Crafted for high-performance teams.</p>
          <div className="flex gap-6 text-gray-400">
            <a href="#" className="hover:text-black transition-colors"><Github size={20} /></a>
          </div>
        </div>
      </footer>
    </div>
  );
}
