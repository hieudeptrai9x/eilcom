import React, { useState } from 'react';
import { Plus, Link as LinkIcon, Loader2 } from 'lucide-react';
import { ProductPayload } from '../types';

interface ProductFormProps {
  onAdd: (payload: ProductPayload) => Promise<boolean>;
}

export default function ProductForm({ onAdd }: ProductFormProps) {
  const [name, setName] = useState('');
  const [brand, setBrand] = useState('');
  const [tags, setTags] = useState('');
  const [links, setLinks] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !brand || !links) return;

    setIsSubmitting(true);
    const imageLinks = links.split('\n').filter(l => l.trim() !== '');
    const tagsArray = tags.split(',').map(t => t.trim()).filter(t => t !== '');
    
    const success = await onAdd({ name, brand, tags: tagsArray, imageLinks });
    
    if (success) {
      setName('');
      setBrand('');
      setTags('');
      setLinks('');
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    }
    setIsSubmitting(false);
  };

  return (
    <div className="glass-card p-8 rounded-3xl mb-12">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-black text-white rounded-xl">
          <Plus size={20} />
        </div>
        <h2 className="text-xl font-semibold tracking-tight">Thêm sản phẩm mới</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="space-y-2">
            <label className="text-xs font-medium uppercase tracking-wider text-gray-500 ml-1">Tên sản phẩm</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ví dụ: Dyson Supersonic"
              className="w-full px-4 py-3 rounded-2xl bg-gray-50 border-none focus:ring-2 focus:ring-black/5 transition-all outline-none"
              required
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-medium uppercase tracking-wider text-gray-500 ml-1">Hãng / Thương hiệu</label>
            <input
              type="text"
              value={brand}
              onChange={(e) => setBrand(e.target.value)}
              placeholder="Ví dụ: Dyson"
              className="w-full px-4 py-3 rounded-2xl bg-gray-50 border-none focus:ring-2 focus:ring-black/5 transition-all outline-none"
              required
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-medium uppercase tracking-wider text-gray-500 ml-1">Tags (Phân cách bằng dấu phẩy)</label>
          <input
            type="text"
            value={tags}
            onChange={(e) => setTags(e.target.value)}
            placeholder="Ví dụ: máy sấy tóc, dyson, làm đẹp, quà tặng"
            className="w-full px-4 py-3 rounded-2xl bg-gray-50 border-none focus:ring-2 focus:ring-black/5 transition-all outline-none"
          />
        </div>

        <div className="space-y-2">
          <label className="text-xs font-medium uppercase tracking-wider text-gray-500 ml-1 flex items-center gap-2">
            <LinkIcon size={14} /> Danh sách Link ảnh (Mỗi dòng 1 link)
          </label>
          <textarea
            value={links}
            onChange={(e) => setLinks(e.target.value)}
            placeholder="https://example.com/image1.jpg&#10;https://example.com/image2.jpg"
            rows={4}
            className="w-full px-4 py-3 rounded-2xl bg-gray-50 border-none focus:ring-2 focus:ring-black/5 transition-all outline-none resize-none"
            required
          />
        </div>

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full md:w-auto px-8 py-3 bg-black text-white rounded-2xl font-medium hover:bg-gray-800 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {isSubmitting ? <Loader2 className="animate-spin" size={20} /> : "Lưu sản phẩm"}
        </button>

        {showSuccess && (
          <p className="text-emerald-600 text-sm font-medium animate-in fade-in slide-in-from-bottom-2">
            ✓ Đã gửi dữ liệu lên Google Sheets thành công!
          </p>
        )}
      </form>
    </div>
  );
}
