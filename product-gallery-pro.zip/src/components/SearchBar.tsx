import { Search } from 'lucide-react';

interface SearchBarProps {
  value: string;
  onChange: (val: string) => void;
}

export default function SearchBar({ value, onChange }: SearchBarProps) {
  return (
    <div className="relative w-full max-w-2xl mx-auto mb-12">
      <div className="absolute inset-y-0 left-5 flex items-center pointer-events-none text-gray-400">
        <Search size={20} />
      </div>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Tìm kiếm theo tên, thương hiệu hoặc #tags..."
        className="w-full pl-14 pr-6 py-5 rounded-[2rem] bg-white border-none shadow-sm focus:shadow-md focus:ring-0 transition-all text-lg outline-none placeholder:text-gray-300"
      />
    </div>
  );
}
