import React, { useState } from 'react';
import { Download, Check, Copy, Image as ImageIcon } from 'lucide-react';
import { ImageItem } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface ImageCardProps {
  item: ImageItem;
  index: number;
  onPreview?: (item: ImageItem) => void;
}

const ProductCard: React.FC<ImageCardProps> = ({ item, index, onPreview }) => {
  const [copied, setCopied] = useState(false);
  const [copying, setCopying] = useState(false);

  const handleCopyImage = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (copying) return;
    setCopying(true);
    try {
      // Use our backend proxy to bypass CORS
      const proxyUrl = `/api/proxy-image?url=${encodeURIComponent(item.url)}`;
      const response = await fetch(proxyUrl);
      if (!response.ok) throw new Error("Fetch failed");
      const blob = await response.blob();
      
      // Convert to PNG using Canvas (ClipboardItem usually only supports image/png)
      const img = new Image();
      const blobUrl = URL.createObjectURL(blob);
      
      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = reject;
        img.src = blobUrl;
      });

      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error("Could not get canvas context");
      ctx.drawImage(img, 0, 0);
      
      const pngBlob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, 'image/png', 1.0));
      URL.revokeObjectURL(blobUrl);

      if (!pngBlob) throw new Error("Failed to create PNG blob");

      await navigator.clipboard.write([
        new ClipboardItem({
          'image/png': pngBlob
        })
      ]);
      
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy image directly:', err);
      // Final fallback to copy link if everything fails
      try {
        await navigator.clipboard.writeText(item.url);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch (clipErr) {
        console.error('Final fallback failed:', clipErr);
      }
    } finally {
      setCopying(false);
    }
  };

  const handleDownload = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      // Use our backend proxy to bypass CORS for download
      const proxyUrl = `/api/proxy-image?url=${encodeURIComponent(item.url)}`;
      const response = await fetch(proxyUrl);
      const contentType = response.headers.get('content-type');
      const extension = contentType?.split('/')[1] || 'jpg';
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${item.productName.replace(/\s+/g, '-').toLowerCase()}-${index}.${extension}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (err) {
      console.error('Download error:', err);
      window.open(item.url, '_blank');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: (index % 20) * 0.02 }}
      onClick={() => onPreview?.(item)}
      className="group relative overflow-hidden rounded-3xl bg-white border border-gray-100 shadow-sm cursor-pointer transition-all duration-500 hover:shadow-2xl hover:-translate-y-1 aspect-[3/4]"
    >
      {/* Image */}
      <img
        src={item.url}
        alt={item.productName}
        referrerPolicy="no-referrer"
        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
      />

      {/* Product Name Badge (Always visible or visible on hover) */}
      <div className="absolute top-4 left-4 z-10">
        <div className="px-3 py-1.5 bg-black/40 backdrop-blur-md border border-white/10 rounded-xl text-[10px] font-bold text-white flex items-center gap-2">
          <ImageIcon size={12} className="text-emerald-400" />
          <span className="truncate max-w-[120px]">{item.productName}</span>
        </div>
      </div>

      {/* Overlay on Hover */}
      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-between p-4">
        <div className="flex justify-end">
          <button
            onClick={handleDownload}
            className="p-2 bg-white/20 backdrop-blur-md border border-white/30 rounded-xl text-white hover:bg-white/40 transition-colors"
            title="Tải về"
          >
            <Download size={18} />
          </button>
        </div>

        <div className="text-white">
          <p className="text-[10px] uppercase tracking-widest font-bold text-white/70">{item.brand}</p>
          <h3 className="text-sm font-semibold truncate">{item.productName}</h3>
          
          {item.tags && item.tags.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {item.tags.slice(0, 3).map((tag, i) => (
                <span key={i} className="px-1.5 py-0.5 bg-white/10 border border-white/10 rounded-md text-[8px] font-medium">
                  #{tag}
                </span>
              ))}
              {item.tags.length > 3 && (
                <span className="text-[8px] text-white/50">+{item.tags.length - 3}</span>
              )}
            </div>
          )}
          
          <p className="text-[9px] text-white/50 mt-1 italic">Click để xem ảnh lớn</p>
        </div>
      </div>

      {/* Copy Success Indicator */}
      <AnimatePresence>
        {(copied || copying) && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-sm z-20"
          >
            <div className="flex flex-col items-center gap-2">
              {copying ? (
                <motion.div 
                  animate={{ rotate: 360 }}
                  transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                  className="w-12 h-12 border-4 border-white/20 border-t-white rounded-full"
                />
              ) : (
                <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center text-white">
                  <Check size={24} />
                </div>
              )}
              <span className="text-white font-bold text-sm">
                {copying ? "Đang xử lý ảnh..." : "Đã copy ảnh!"}
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Static Copy Button */}
      <button 
        onClick={handleCopyImage}
        className="absolute bottom-4 right-4 p-2 bg-black/20 backdrop-blur-md rounded-xl text-white opacity-0 group-hover:opacity-100 transition-all hover:bg-black/40 z-10"
        title="Copy ảnh"
      >
        <Copy size={16} />
      </button>
    </motion.div>
  );
};

export default ProductCard;
