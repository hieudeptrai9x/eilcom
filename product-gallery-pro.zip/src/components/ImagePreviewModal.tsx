import React, { useState, useEffect } from 'react';
import { X, Download, Copy, Check, ChevronLeft, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ImageItem } from '../types';

interface ImagePreviewModalProps {
  items: ImageItem[];
  initialIndex: number;
  onClose: () => void;
}

export default function ImagePreviewModal({ items, initialIndex, onClose }: ImagePreviewModalProps) {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [copied, setCopied] = useState(false);
  const [copying, setCopying] = useState(false);
  const [direction, setDirection] = useState(0);

  const item = items[currentIndex];

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') handleNext();
      if (e.key === 'ArrowLeft') handlePrev();
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex]);

  const handleNext = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    setDirection(1);
    setCurrentIndex((prev) => (prev + 1) % items.length);
  };

  const handlePrev = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    setDirection(-1);
    setCurrentIndex((prev) => (prev - 1 + items.length) % items.length);
  };

  if (!item) return null;

  const handleCopy = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (copying) return;
    setCopying(true);
    try {
      const proxyUrl = `/api/proxy-image?url=${encodeURIComponent(item.url)}`;
      const response = await fetch(proxyUrl);
      const blob = await response.blob();
      
      const img = new Image();
      const blobUrl = URL.createObjectURL(blob);
      
      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = reject;
        img.src = blobUrl;
      });

      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(img, 0, 0);
        const pngBlob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, 'image/png', 1.0));
        if (pngBlob) {
          await navigator.clipboard.write([
            new ClipboardItem({ 'image/png': pngBlob })
          ]);
          setCopied(true);
          setTimeout(() => setCopied(false), 2000);
        }
      }
      URL.revokeObjectURL(blobUrl);
    } catch (err) {
      console.error('Copy failed:', err);
      try {
        await navigator.clipboard.writeText(item.url);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch (e) {}
    } finally {
      setCopying(false);
    }
  };

  const handleDownload = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const proxyUrl = `/api/proxy-image?url=${encodeURIComponent(item.url)}`;
      const response = await fetch(proxyUrl);
      const contentType = response.headers.get('content-type');
      const extension = contentType?.split('/')[1] || 'jpg';
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${item.productName.replace(/\s+/g, '-').toLowerCase()}.${extension}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (err) {
      window.open(item.url, '_blank');
    }
  };

  const variants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 300 : -300,
      opacity: 0
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 300 : -300,
      opacity: 0
    })
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8 bg-black/95 backdrop-blur-2xl"
        onClick={onClose}
      >
        {/* Close Button */}
        <motion.button
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="absolute top-6 right-6 p-3 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors z-50"
          onClick={onClose}
        >
          <X size={24} />
        </motion.button>

        {/* Navigation Buttons */}
        <div className="absolute inset-y-0 left-0 flex items-center px-2 md:px-4 z-40">
          <button 
            onClick={handlePrev}
            className="p-2 md:p-4 bg-white/5 hover:bg-white/10 rounded-full text-white transition-all backdrop-blur-md border border-white/10 group"
          >
            <ChevronLeft size={24} className="md:w-8 md:h-8 group-active:scale-90 transition-transform" />
          </button>
        </div>
        <div className="absolute inset-y-0 right-0 flex items-center px-2 md:px-4 z-40">
          <button 
            onClick={handleNext}
            className="p-2 md:p-4 bg-white/5 hover:bg-white/10 rounded-full text-white transition-all backdrop-blur-md border border-white/10 group"
          >
            <ChevronRight size={24} className="md:w-8 md:h-8 group-active:scale-90 transition-transform" />
          </button>
        </div>

        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="relative max-w-5xl w-full max-h-full flex flex-col items-center gap-6"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="relative group w-full flex justify-center overflow-hidden">
            <AnimatePresence initial={false} custom={direction} mode="wait">
              <motion.img
                key={currentIndex}
                src={item.url}
                custom={direction}
                variants={variants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{
                  x: { type: "spring", stiffness: 300, damping: 30 },
                  opacity: { duration: 0.2 }
                }}
                drag="x"
                dragConstraints={{ left: 0, right: 0 }}
                dragElastic={1}
                onDragEnd={(_, info) => {
                  if (info.offset.x < -100) handleNext();
                  else if (info.offset.x > 100) handlePrev();
                }}
                alt={item.productName}
                className="max-w-full max-h-[70vh] object-contain rounded-2xl shadow-2xl border border-white/10 cursor-grab active:cursor-grabbing"
                referrerPolicy="no-referrer"
              />
            </AnimatePresence>
          </div>

          <div className="w-full max-w-2xl bg-white/10 backdrop-blur-md border border-white/10 p-6 rounded-[2rem] text-white">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-xs uppercase tracking-[0.3em] font-bold text-white/50">{item.brand}</p>
                  <span className="text-[10px] bg-white/10 px-2 py-0.5 rounded-full text-white/40 font-mono">
                    {currentIndex + 1} / {items.length}
                  </span>
                </div>
                <h2 className="text-2xl font-bold tracking-tight">{item.productName}</h2>
                {item.tags && item.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-3">
                    {item.tags.map((tag, i) => (
                      <span key={i} className="px-2 py-1 bg-white/5 border border-white/10 rounded-lg text-[10px] font-medium text-white/70">
                        #{tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>
              
              <div className="flex items-center gap-3">
                <button
                  onClick={handleCopy}
                  disabled={copying}
                  className="flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-3 bg-white text-black rounded-xl font-bold hover:bg-gray-200 transition-all disabled:opacity-50"
                >
                  {copying ? (
                    <div className="w-5 h-5 border-2 border-black/20 border-t-black rounded-full animate-spin" />
                  ) : copied ? (
                    <Check size={18} />
                  ) : (
                    <Copy size={18} />
                  )}
                  {copied ? "Đã copy" : "Copy ảnh"}
                </button>
                
                <button
                  onClick={handleDownload}
                  className="p-3 bg-white/10 hover:bg-white/20 rounded-xl text-white transition-colors border border-white/10"
                  title="Tải về"
                >
                  <Download size={20} />
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
