import { ImageItem } from '../types';
import ProductCard from './ProductCard';
import { Loader2, PackageOpen } from 'lucide-react';

interface ProductGridProps {
  items: ImageItem[];
  loading: boolean;
  onPreview?: (item: ImageItem) => void;
}

export default function ProductGrid({ items, loading, onPreview }: ProductGridProps) {
  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-24 gap-4">
        <Loader2 className="animate-spin text-gray-300" size={48} />
        <p className="text-gray-400 font-medium">Đang đồng bộ với Google Sheets...</p>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-24 bg-white rounded-[3rem] border border-dashed border-gray-200">
        <PackageOpen className="text-gray-200 mb-4" size={64} />
        <h3 className="text-xl font-semibold text-gray-400">Không tìm thấy ảnh nào</h3>
        <p className="text-gray-400">Hãy thử tìm kiếm từ khóa khác hoặc thêm sản phẩm mới.</p>
      </div>
    );
  }

  return (
    <div className="bento-grid">
      {items.map((item, index) => (
        <ProductCard 
          key={`${item.id}-${index}`} 
          item={item} 
          index={index} 
          onPreview={onPreview}
        />
      ))}
    </div>
  );
}
